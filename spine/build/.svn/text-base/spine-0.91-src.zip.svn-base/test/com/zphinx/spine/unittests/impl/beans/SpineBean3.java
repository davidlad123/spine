/**
 * SpineBean3.java
 * @author David Ladapo (davidl@zphinx.com)
 * @version  1.0
 * 
 * <p>Copyright &copy;Zphinx Software Solutions</p>
 * 
 **/

package com.zphinx.spine.unittests.impl.beans;

import com.zphinx.spine.vo.dto.SpineBean;

/**
 * SpineBean3
 * 
 * @author David Ladapo
 * @version $1.0
 *          <p>
 *          Created: Dec 14, 2007 11:11:12 PM<br>
 *          Copyright &copy;Zphinx Software Solutions
 *          </p>
 */
public class SpineBean3 extends SpineBean {

    /**
     * Public Constructor
     */
    public SpineBean3() {
        // TODO Auto-generated constructor stub
    }

}
