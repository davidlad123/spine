/**
 * SpineBean1.java
 * @author David Ladapo (davidl@zphinx.com)
 * @version  1.0
 * 
 * <p>Copyright &copy;Zphinx Software Solutions</p>
 * 
 **/

package com.zphinx.spine.unittests.impl.beans;

import com.zphinx.spine.vo.dto.SpineBean;

/**
 * SpineBean1
 * 
 * @author David Ladapo
 * @version $1.0
 *          <p>
 *          Created: Dec 14, 2007 11:04:44 PM<br>
 *          Copyright &copy;Zphinx Software Solutions
 *          </p>
 */
public class SpineBean1 extends SpineBean {

    /**
     * Public Constructor
     */
    public SpineBean1() {

    }

}
