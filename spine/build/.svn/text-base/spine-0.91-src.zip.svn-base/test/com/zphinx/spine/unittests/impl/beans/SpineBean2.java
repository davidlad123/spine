/**
 * SpineBean2.java
 * @author David Ladapo (davidl@zphinx.com)
 * @version  1.0
 * 
 * <p>Copyright &copy;Zphinx Software Solutions</p>
 * 
 **/

package com.zphinx.spine.unittests.impl.beans;

import com.zphinx.spine.vo.dto.SpineBean;

/**
 * SpineBean2
 * 
 * @author David Ladapo
 * @version $1.0
 *          <p>
 *          Created: Dec 14, 2007 11:05:16 PM<br>
 *          Copyright &copy;Zphinx Software Solutions
 *          </p>
 */
public class SpineBean2 extends SpineBean {

    /**
     * Public Constructor
     */
    public SpineBean2() {
        // TODO Auto-generated constructor stub
    }

}
