/**
 * ExampleBuilder.java
 * @author David Ladapo (davidl@zphinx.com)
 * @version  1.0
 * 
 * <p>Copyright &copy;Zphinx Software Solutions</p>
 * 
 **/

package com.zphinx.spine.examples.multiview;

import com.zphinx.spine.core.AbstractBuilder;

/**
 * ExampleBuilder is a simple builder used in the spine examples
 * 
 * @author David Ladapo
 * @version $1.0
 *          <p>
 *          Created: Dec 29, 2007 2:47:23 AM<br>
 *          Copyright &copy;Zphinx Software Solutions
 *          </p>
 */
public class ExampleBuilder extends AbstractBuilder {

    /**
     * Public Constructor
     */
    public ExampleBuilder() {
       super();
    }

}
